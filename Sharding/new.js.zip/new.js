const MongoClient = require('mongodb').MongoClient;
global.hostdb = "localhost";
global.presentShard=-1;

function insertDocument( db, collection_name, data, callback){
	console.log("collection_name"+collection_name);
	db.collection(collection_name).insertOne(data,
		function(err, result) {
		// assert.equal(err, null);
		console.log("Inserted a document into the "+collection_name+" collection.");
		callback(result);
		}); 
}



function findDocument( db, collection_name, query, cal){
	console.log("Inside findDocument");
	console.log(JSON.parse(query));
	db.collection(collection_name).find(JSON.parse(query)).toArray(function(err, result){
		if (err) throw err;
		// numRows = result.length;
		console.log("result is = ",result);
		db.close();
	    return cal(result);

	});
	
}

function ifExists( dbName, bool ,callback ){
	console.log("Inside ifExists");
	var MongoClient = require('mongodb').MongoClient;
	var assert = require('assert');
	var ObjectId = require('mongodb').ObjectID;
	var url = 'mongodb://'+global.hostdb+'/DBindex';

	var query = '{ "dbName":"'+dbName+'" }';
	console.log("query=", query);
	var res="";
	MongoClient.connect(url, function(err, db) {
	  assert.equal(null, err);
	  findDocument(db, "dbInfo", query , function(r) {
	  	  	
	  	  	if(bool == 1)
	  	  	{
	  	  		if(r.length > 0){
	  	  		   	callback(1);
	  	  		}
	  	  		else{
	  	  			callback(0);
	  	  		}
	  	  	}
	  	  	else
	  	  	{
	  	  		callback(r);
	  	  	}
    	db.close();
	  });
	  console.log("Query Executed");
	  db.close();
	});	



}

function selectDatabase( dbName , callback){

	ifExists( dbName,0, function(res){
		if(res == 0){
			global.currentDb = 'undefined';
			ret = {success:"False", message:"No database by the name exists, create one to proceed"};	
			callback(ret);
		}
		else{
			console.log(res);
			global.currentDb = dbName;
			global.host = res[0].host;
			global.numShards = res[0].numShards;
			console.log("host=", global.host, global.numShards);
			var len = global.host.length;
			  	  	if(len<numShards){
			  	  		for (var i = len; i < numShards; i++) {
				  	  		global.host.push(global.host[i%len]);			  	  			
			  	  		}
			  	  	}
			ret = {success:"True", message:"Databse present and successfully selected"};
			callback(ret);	
		}
	});
}

function createDatabase( dbName, host, hostdb, numShards, callback) {


	console.log("Inside createDatabase");
	if(typeof dbName === 'undefined')
	{
		err="Lack of arguements. No database name passed.";
	}
	if(typeof numShards === 'undefined')
	{
		numShards = 1;
	}
	if(typeof host === 'undefined')
	{
		host = "localhost:27017";
	}
	if(typeof hostdb === 'undefined')
	{
		hostdb = "localhost:27017";
	}

	global.hostdb = hostdb;

	ifExists(dbName,1, function(res){
		if(res==1){
			console.log("Database already present");
		ret = {success:"False", message: "Database by the given name already present. Choose a new name to continue."};	
		callback(ret);
		}
		else{
			console.log("Database not present");

			var MongoClient = require('mongodb').MongoClient;
			var assert = require('assert');
			var ObjectId = require('mongodb').ObjectID;
			var url = 'mongodb://'+global.hostdb+':27017/DBindex';

			var obj = {dbName:dbName, host:host, numShards:numShards};
			console.log("Object to be inserted=",obj);

			MongoClient.connect(url, function(err, db) {
			  assert.equal(null, err);
			  insertDocument(db, "dbInfo", obj, function(res) {
			  	// console.log(res);
			      db.close();
			  });
			});
			ret = {success:"True", message:"Database created successfully with the required hosts."};
			callback(ret);
		}
	});
}

function insert( query, collection_name, callback){
	
	global.presentShard = global.presentShard+1;
	global.presentShard = global.presentShard % global.numShards;

	var url = 'mongodb://'+global.host[global.presentShard]+'/'+global.currentDb+'_'+global.presentShard;
		
	
		MongoClient.connect(url, function(err, db) {

			insertDocument(db, collection_name, JSON.parse(query), function(res){
				console.log("Inserted successfully");
				callback(res);
			});
			
		});
	
}


function insertData( query, collection_name, callback){
	console.log("inside insertData");
	if( global.currentDb === 'undefined'){
		console.log("undefined currentDb");
		err = "No database selected, select a databse to insert data into.";
		callback(err);
	}
	else{
		console.log("currentDb set", global.host);
		// if(typeof global.host === 'undefined'){
		// 	console.log("undefined hosts");
			// find_query = '{"dbName":"'+global.currentDb+'"}';
			// var url = 'mongodb://'+global.hostdb+'/DBindex';
			// MongoClient.connect(url, function(err, db) {
			//   // assert.equal(null, err);
			  // findDocument(db, "dbInfo", find_query , function(res) {
			  	  	// global.host = res[0].host;
			  	  	// global.numShards = res[0].numShards;
			  	  	// var len = global.host.length;
			  	  	// if(len<numShards){
			  	  	// 	for (var i = len; i < numShards; i++) {
			  	  	// 		console.log(global.host[i%len]);
				  	  // 		global.host.push(global.host[i%len]);			  	  			
			  	  	// 	}
			  	  	// }
			  	  	insert( query, collection_name, function(res2){
			  	  		console.log("back to insertData")
			  	  		callback(res2);
			  	  	})
			  	  	// callback(res);

			  // });
			  // db.close();
			// });	
			
			
		// }

	}
}

function find( query, collection_name, callback){
	console.log("Inside find");
	var result = [];
	console.log(global.numShards);
	for( i=0 ; i<global.numShards ; i++){
		var url = 'mongodb://'+global.host[i]+'/'+global.currentDb+'_'+i;
		console.log(url);
		MongoClient.connect(url, function(err,db){

			findDocument(db, collection_name, query, function(res){
				console.log(res);
				result.push(res);
			});
		});
	}

	callback(result);

}

// selectDatabase("prabhat", function(res){
// find('{"name":"prabhat"}', "student", function(res2){

// 	console.log("all documents=",res2);
// });

// });

// createDatabase( "shriti", ['localhost','192.168.43.142'], "localhost", 3, function(res){
// 	console.log(res);
// });

selectDatabase("shriti", function(res){
	// console.log("res=",res);
	query = '{"name":"shriti", "enrollment":"15803012"}';
	insertData( query, 'student', function(res2){
		console.log("back to main");
		console.log("back to main 1");
		// process.exit()
		return 1;
	});
	insertData( query, 'student', function(res2){
		console.log("back to main");
		console.log("back to main 1");
		// process.exit()
		return 1;
	});
	insertData( query, 'student', function(res2){
		console.log("back to main");
		console.log("back to main 1");
		// process.exit()
		return 1;
	});
	insertData( query, 'student', function(res2){
		console.log("back to main");
		console.log("back to main 1");
		// process.exit()
		return 1;
	});
	console.log("back to main 2");
	// return 1;
});

console.log("ended");